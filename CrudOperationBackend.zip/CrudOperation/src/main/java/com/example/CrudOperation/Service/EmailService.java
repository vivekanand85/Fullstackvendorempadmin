package com.example.CrudOperation.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CrudOperation.entity.SentEmail;
import com.example.CrudOperation.entity.Vendor;
import com.example.CrudOperation.repository.SentEmailRepository;


@Service
public class EmailService {

	
	@Autowired
	private SentEmailRepository sentEmailRepository;
	
	public SentEmail sendEmail(Vendor vendor) {
        String content = String.format("Sending payments to vendor %s at upi %s", vendor.getName(), vendor.getUpi());
        SentEmail email = new SentEmail();
        email.setContent(content);
        email.setTimestamp(LocalDateTime.now());
        System.out.println(content);  // Mock sending email
        return sentEmailRepository.save(email);
	}
	
	public List<SentEmail> getAllSentEmails() {
        return sentEmailRepository.findAll();
    }

	
}
