package com.example.CrudOperation.admin;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.CrudOperation.Service.EmailService;
import com.example.CrudOperation.Service.EmployeeService;
import com.example.CrudOperation.Service.VendorService;
import com.example.CrudOperation.entity.Employee;
import com.example.CrudOperation.entity.SentEmail;
import com.example.CrudOperation.entity.Vendor;


@RestController
@RequestMapping("/api")
public class AdminControoler {

	
	 @Autowired
	    private EmployeeService employeeService;

	    @Autowired
	    private VendorService vendorService;

	    @Autowired
	    private EmailService emailService;

	    @PostMapping("/employees")
	    public Employee createEmployee(@RequestBody Employee employee) {
	        return employeeService.createEmployee(employee);
	    }

	    @PostMapping("/vendors")
	    public Vendor createVendor(@RequestBody Vendor vendor) {
	        return vendorService.createVendor(vendor);
	    }

	    @PostMapping("/vendors/send-email")
	    public List<SentEmail> sendEmail(@RequestBody List<String> vendorEmails) {
	        List<Vendor> vendors = vendorService.getAllVendors().stream()
	                .filter(vendor -> vendorEmails.contains(vendor.getEmail()))
	                .collect(Collectors.toList());
	        return vendors.stream()
	                .map(emailService::sendEmail)
	                .collect(Collectors.toList());
	    }

	    @GetMapping("/employees")
	    public List<Employee> getAllEmployees() {
	        return employeeService.getAllEmployees();
	    }

	    @GetMapping("/vendors")
	    public List<Vendor> getAllVendors() {
	        return vendorService.getAllVendors();
	    }

	    @GetMapping("/emails")
	    public List<SentEmail> getAllSentEmails() {
	        return emailService.getAllSentEmails();
	    }
}
