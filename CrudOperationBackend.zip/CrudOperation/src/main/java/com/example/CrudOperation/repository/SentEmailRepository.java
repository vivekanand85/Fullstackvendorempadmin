package com.example.CrudOperation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CrudOperation.entity.SentEmail;

public interface SentEmailRepository extends JpaRepository<SentEmail, Long>{

}
