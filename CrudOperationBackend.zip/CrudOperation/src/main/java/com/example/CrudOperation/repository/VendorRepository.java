package com.example.CrudOperation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CrudOperation.entity.Vendor;

public interface VendorRepository extends JpaRepository<Vendor, String>{

}
