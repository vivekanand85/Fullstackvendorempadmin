package com.example.CrudOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
